from django.contrib import admin
from application.models import names
# Register your models here.
admin.site.register(names)